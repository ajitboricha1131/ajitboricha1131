﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter any number");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, old = 0, New = 0;
            do
            {
                if (i <= 3)
                {
                    Console.Write(i);
                    New = i;
                    old = i - 1;
                }
                else
                {
                    int temp = old * New;
                    if (temp > n)
                    {
                        break;
                    }
                    Console.WriteLine(temp);
                    old = New;
                    New = temp;
                }
                i++;
            }
            while (i < n);
            Console.Read();

            //while loop:
            while (i < n)
            {
                if (i < 3)
                {
                    Console.WriteLine();
                }
                else
                {
                    int temp = old * New;
                    if (temp > n)
                    {
                        break;
                    }
                    Console.WriteLine(temp);
                    old = New;
                    New = temp;
                }
                i++;
            }
            //for loop
            for (i = 1; i < n; i++)
            {
                if (i <= 3)
                {
                    Console.Write(i);
                    New = i;
                    old = i - 1;
                    if (i == 3)
                        Console.WriteLine();
                }
                else
                {
                    i = old * New;
                    if (i > n)
                    {
                        break;
                    }
                    Console.WriteLine(i);
                    old = New;
                    New = i;
                }
            }
            Console.Read();
        }
    }
}
