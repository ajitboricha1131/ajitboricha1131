﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            //boxing
            int i = 10;
            Object b1 = i;
            Console.Write(b1);
            
            //unboxing
            int j = (int)b1;
            Console.Write(j);
            Console.Read();
        }
    }
}
